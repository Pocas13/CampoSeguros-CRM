export default function ClientsPage() {
  return (
    <div>

      <div className="mb-8 flex items-center justify-between">

        <h1 className="text-3xl font-bold">
          Clientes
        </h1>

        <button className="rounded-lg bg-blue-600 px-5 py-3 text-white hover:bg-blue-700">
          + Novo Cliente
        </button>

      </div>

      <input
        placeholder="Pesquisar cliente..."
        className="mb-6 w-full rounded-lg border px-4 py-3"
      />

      <div className="overflow-hidden rounded-xl border bg-white">

        <table className="w-full">

          <thead className="bg-slate-100">

            <tr>

              <th className="p-4 text-left">Nome</th>

              <th className="p-4 text-left">NIF</th>

              <th className="p-4 text-left">Telefone</th>

              <th className="p-4 text-left">Email</th>

              <th className="p-4 text-left">Ações</th>

            </tr>

          </thead>

          <tbody>

            <tr className="border-t">

              <td className="p-4">Daniel Campos</td>

              <td className="p-4">123456789</td>

              <td className="p-4">912345678</td>

              <td className="p-4">daniel@email.pt</td>

              <td className="p-4">

                <button className="mr-2 rounded bg-slate-200 px-3 py-1">
                  Editar
                </button>

                <button className="rounded bg-red-600 px-3 py-1 text-white">
                  Apagar
                </button>

              </td>

            </tr>

          </tbody>

        </table>

      </div>

    </div>
  );
}